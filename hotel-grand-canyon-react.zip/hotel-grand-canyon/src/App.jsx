import { useState } from 'react'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import About from './components/About'
import Rooms from './components/Rooms'
import BookingForm from './components/BookingForm'
import Reviews from './components/Reviews'
import Amenities from './components/Amenities'
import Location from './components/Location'
import Contact from './components/Contact'
import Footer from './components/Footer'

export default function App() {
  // Lifted here so a "Book Now" click on a room card pre-selects that room
  // in the booking form below.
  const [selectedRoomId, setSelectedRoomId] = useState('')

  return (
    <>
      <Navbar />
      <Hero />
      <About />
      <Rooms onBookRoom={setSelectedRoomId} />

      <section className="section" id="booking">
        <div className="container">
          <div className="section-head">
            <h2>Reserve your room</h2>
            <p>
              This sends a booking request straight to our front desk on WhatsApp &mdash; not a
              payment. We&rsquo;ll confirm availability and payment details with you directly.
            </p>
          </div>
          <BookingForm selectedRoomId={selectedRoomId} onSelectRoom={setSelectedRoomId} />
        </div>
      </section>

      <Reviews />
      <Amenities />
      <Location />
      <Contact />
      <Footer />
    </>
  )
}
