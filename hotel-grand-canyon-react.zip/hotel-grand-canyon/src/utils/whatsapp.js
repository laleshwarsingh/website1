import { hotel } from '../data/hotelConfig'
import { formatDateForDisplay } from './dateUtils'

// Builds a WhatsApp click-to-chat URL (https://wa.me/<number>?text=<message>)
// pre-filled with the full booking request. This is the standard WhatsApp
// click-to-chat mechanism — no backend or WhatsApp Business API call happens
// here. The user still has to press Send inside WhatsApp.
//
// To later switch this to fully automatic sending via the official WhatsApp
// Business Cloud API, replace only this function's return value: instead of
// returning a wa.me URL to open, POST the same fields to your backend, which
// calls https://graph.facebook.com/vXX.X/<phone-number-id>/messages with a
// WhatsApp Cloud API access token. Every field below is already structured
// as a flat object for that purpose.
export function buildBookingWhatsAppUrl(booking) {
  const {
    fullName,
    mobile,
    email,
    checkIn,
    checkOut,
    nights,
    guests,
    numberOfRooms,
    occupancy,
    roomPrice,
    total,
    specialRequest,
  } = booking

  const lines = [
    'HOTEL GRAND CANYON \u2013 NEW BOOKING REQUEST',
    '',
    `Customer Name: ${fullName}`,
    `Mobile: ${mobile}`,
    `Email: ${email || 'Not provided'}`,
    `Check-in Date: ${formatDateForDisplay(checkIn)}`,
    `Check-out Date: ${formatDateForDisplay(checkOut)}`,
    `Total Nights: ${nights}`,
    `Total Guests: ${guests}`,
    `Number of Rooms: ${numberOfRooms}`,
    `Room/Occupancy: ${occupancy}`,
    `Room Price: ${roomPrice}`,
    `Estimated Total: ${total}`,
    `Special Request: ${specialRequest ? specialRequest : 'None'}`,
  ]

  const message = lines.join('\n')
  return `https://wa.me/${hotel.whatsappNumber}?text=${encodeURIComponent(message)}`
}
