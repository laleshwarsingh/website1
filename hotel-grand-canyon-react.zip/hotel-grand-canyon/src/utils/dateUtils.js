// All dates are handled as 'YYYY-MM-DD' strings (native <input type="date"> format)
// so comparisons are simple string/Date comparisons with no timezone surprises
// for same-day checks.

export function todayISO() {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return toISO(d)
}

function toISO(date) {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}

// Returns number of nights between two ISO date strings (checkout - checkin).
// Returns 0 or a negative number if the range is invalid.
export function nightsBetween(checkIn, checkOut) {
  if (!checkIn || !checkOut) return 0
  const inDate = new Date(checkIn + 'T00:00:00')
  const outDate = new Date(checkOut + 'T00:00:00')
  const diffMs = outDate.getTime() - inDate.getTime()
  return Math.round(diffMs / (1000 * 60 * 60 * 24))
}

export function formatDateForDisplay(iso) {
  if (!iso) return ''
  const d = new Date(iso + 'T00:00:00')
  return d.toLocaleDateString('en-IN', {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  })
}
