// ─────────────────────────────────────────────────────────────────────────
// EVERYTHING ABOUT THE HOTEL LIVES IN THIS ONE FILE.
// Edit prices, phone numbers, rooms, reviews and amenities here only —
// no other file contains hardcoded hotel data.
// ─────────────────────────────────────────────────────────────────────────

export const hotel = {
  name: 'Hotel Grand Canyon',
  tagline: 'A steady, comfortable stay on Raipur\u2019s VIP Road',
  city: 'Raipur, Chhattisgarh',
  address: 'VIP Road, Near Agrasen Dham, Fundahar, Raipur, Chhattisgarh \u2013 492001',

  // Two front-desk numbers (calls)
  phones: ['7024129726', '8817320007'],

  // WhatsApp booking number, in international format for wa.me links (no + or spaces)
  whatsappNumber: '917024129726',
  whatsappDisplay: '+91 70241 29726',

  // Placeholder — replace with a real inbox before launch
  email: 'reservations@hotelgrandcanyon.example',

  currency: '\u20b9',

  // Replace with the hotel's actual Google Maps share link before launch
  mapsUrl:
    'https://www.google.com/maps/search/?api=1&query=Hotel+Grand+Canyon+VIP+Road+Fundahar+Raipur+Chhattisgarh+492001',

  // Embeddable map (approximate — swap for the exact pin later)
  mapsEmbedUrl:
    'https://www.google.com/maps?q=VIP+Road+Fundahar+Raipur+Chhattisgarh+492001&output=embed',
}

// Room / occupancy pricing — per night, as given by the hotel.
export const rooms = [
  {
    id: 'single',
    occupancy: '1 Person',
    guests: 1,
    price: 1615,
    description:
      'A quiet single room sized for solo business trips and short visits — a firm bed, a proper work corner and nothing you don\u2019t need.',
    image: 'https://picsum.photos/seed/ghc-room-single/800/600',
  },
  {
    id: 'double',
    occupancy: '2 Persons',
    guests: 2,
    price: 1782,
    description:
      'Our most-booked room. Comfortable for a couple or two colleagues travelling together, with room to actually unpack.',
    image: 'https://picsum.photos/seed/ghc-room-double/800/600',
  },
  {
    id: 'triple',
    occupancy: '3 Persons',
    guests: 3,
    price: 3265,
    description:
      'Extra bedding and floor space for three, popular with small families and groups visiting Raipur together.',
    image: 'https://picsum.photos/seed/ghc-room-triple/800/600',
  },
  {
    id: 'quad',
    occupancy: '4 Persons',
    guests: 4,
    price: 3583,
    description:
      'Our largest room, built for families of four who\u2019d rather stay together than book two separate rooms.',
    image: 'https://picsum.photos/seed/ghc-room-quad/800/600',
  },
]

// Editable placeholders — confirm each against what the property actually offers
// before publishing, then set `available: true/false` per item.
export const amenities = [
  { id: 'rooms', label: 'Comfortable Rooms', available: true },
  { id: 'wifi', label: 'Free Wi-Fi', available: true },
  { id: 'frontdesk', label: '24/7 Front Desk', available: true },
  { id: 'parking', label: 'Parking', available: true },
  { id: 'roomservice', label: 'Room Service', available: true },
  { id: 'family', label: 'Family-Friendly Stay', available: true },
  { id: 'ac', label: 'Air Conditioning', available: true },
  { id: 'housekeeping', label: 'Housekeeping', available: true },
]

// Sample reviews — clearly placeholders. Replace with real guest feedback
// before launch; do not present these as verified reviews.
export const reviews = [
  {
    id: 1,
    name: 'Sample Guest \u2014 Ramesh K.',
    rating: 5,
    text: 'Stayed here for two nights on a work trip. Room was clean, staff picked up the phone right away when I needed extra towels. Easy walk to VIP Road.',
  },
  {
    id: 2,
    name: 'Sample Guest \u2014 Priya S.',
    rating: 4,
    text: 'Good value for a family stay near Agrasen Dham. The quad room fit all of us comfortably. Would book again for a short trip.',
  },
  {
    id: 3,
    name: 'Sample Guest \u2014 Ashok T.',
    rating: 5,
    text: 'Front desk was responsive at check-in even though we arrived late. Room was quiet and the AC worked well.',
  },
]

export const navLinks = [
  { label: 'About', href: '#about' },
  { label: 'Rooms', href: '#rooms' },
  { label: 'Book', href: '#booking' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'Amenities', href: '#amenities' },
  { label: 'Location', href: '#location' },
  { label: 'Contact', href: '#contact' },
]
