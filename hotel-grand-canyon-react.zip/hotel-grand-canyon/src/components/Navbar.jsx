import { useState } from 'react'
import { hotel, navLinks } from '../data/hotelConfig'

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  const closeMenu = () => setIsOpen(false)

  return (
    <header className="navbar">
      <div className="navbar__inner">
        <a href="#top" className="navbar__brand" onClick={closeMenu}>
          Hotel <span>Grand Canyon</span>
        </a>

        <ul className="navbar__links">
          {navLinks.map((link) => (
            <li key={link.href}>
              <a href={link.href}>{link.label}</a>
            </li>
          ))}
        </ul>

        <div className="navbar__actions">
          <a
            href={`tel:${hotel.phones[0]}`}
            className="btn btn--outline"
            style={{ padding: '10px 18px' }}
          >
            Call Now
          </a>
          <a href="#booking" className="btn btn--primary" style={{ padding: '10px 20px' }}>
            Book Now
          </a>
        </div>

        <button
          className="navbar__toggle"
          aria-label={isOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={isOpen}
          onClick={() => setIsOpen((prev) => !prev)}
        >
          <span style={isOpen ? { transform: 'translateY(7px) rotate(45deg)' } : undefined} />
          <span style={isOpen ? { opacity: 0 } : undefined} />
          <span style={isOpen ? { transform: 'translateY(-7px) rotate(-45deg)' } : undefined} />
        </button>
      </div>

      <nav className={`navbar__mobile-panel ${isOpen ? 'is-open' : ''}`}>
        {navLinks.map((link) => (
          <a key={link.href} href={link.href} onClick={closeMenu}>
            {link.label}
          </a>
        ))}
        <a href="#booking" className="btn btn--primary btn--full" onClick={closeMenu}>
          Book Now
        </a>
      </nav>
    </header>
  )
}
