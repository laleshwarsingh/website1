import { hotel } from '../data/hotelConfig'

export default function Hero() {
  return (
    <section className="hero" id="top">
      <div className="hero__inner">
        <div>
          <p className="hero__eyebrow">{hotel.city}</p>
          <h1 className="hero__title">{hotel.name}</h1>
          <p className="hero__tagline">{hotel.tagline}. Rooms for every party size, direct booking with no middleman fees.</p>

          <div className="hero__actions">
            <a href="#booking" className="btn btn--primary">
              Book Your Stay
            </a>
            <a href="#rooms" className="btn btn--outline-light">
              See Room Prices
            </a>
          </div>

          <div className="hero__facts">
            <div>
              <span className="hero__fact-num">4</span>
              <p className="hero__fact-label">Room sizes, 1&ndash;4 guests</p>
            </div>
            <div>
              <span className="hero__fact-num">{hotel.currency}1,615</span>
              <p className="hero__fact-label">Starting per night</p>
            </div>
            <div>
              <span className="hero__fact-num">24/7</span>
              <p className="hero__fact-label">Front desk</p>
            </div>
          </div>
        </div>

        <div className="hero__image">
          <img
            src="https://picsum.photos/seed/ghc-hero-exterior/900/1000"
            alt={`Front view of ${hotel.name}`}
          />
        </div>
      </div>
    </section>
  )
}
