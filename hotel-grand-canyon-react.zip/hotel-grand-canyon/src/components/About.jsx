import { hotel } from '../data/hotelConfig'

export default function About() {
  return (
    <section className="section" id="about">
      <div className="container">
        <div className="about__grid">
          <div className="about__image">
            <img
              src="https://picsum.photos/seed/ghc-lobby/700/800"
              alt={`Lobby area at ${hotel.name}`}
            />
          </div>

          <div className="about__body">
            <div className="section-head" style={{ marginBottom: 24 }}>
              <h2>A hotel built around VIP Road, not around brochures</h2>
            </div>
            <p>
              {hotel.name} sits on VIP Road near Agrasen Dham in Fundahar, Raipur &mdash; close enough
              to the city&rsquo;s main routes to be convenient for a late check-in, and quiet enough
              to actually rest. It&rsquo;s the kind of hotel Raipur runs on more than the kind that
              makes headlines: dependable rooms, a front desk that answers the phone, and pricing
              that doesn&rsquo;t change depending on how busy the city is that week.
            </p>
            <p>
              Families visiting Agrasen Dham book our larger rooms together instead of splitting
              across two properties. Business travellers passing through Raipur use us for a clean,
              well-lit room and a fast checkout. Couples and solo tourists get a private, comfortable
              stay without paying for amenities they won&rsquo;t use.
            </p>
            <div className="about__audience">
              <span className="about__chip">Families</span>
              <span className="about__chip">Couples</span>
              <span className="about__chip">Business travellers</span>
              <span className="about__chip">Tourists</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
