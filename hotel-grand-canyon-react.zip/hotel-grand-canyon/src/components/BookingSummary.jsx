import { hotel } from '../data/hotelConfig'
import { formatDateForDisplay } from '../utils/dateUtils'

export default function BookingSummary({ draft, isConfirmed, whatsappUrl }) {
  const { room, checkIn, checkOut, nights, numberOfRooms, guests, total } = draft
  const hasEnoughToShow = room && checkIn && checkOut && nights > 0

  return (
    <aside className="booking-summary">
      <h3>Booking summary</h3>

      {!hasEnoughToShow && (
        <p className="summary-empty">
          Choose a room and your check-in and check-out dates, and your total will appear here
          automatically.
        </p>
      )}

      {hasEnoughToShow && (
        <>
          <div className="summary-row">
            <span>Room / Occupancy</span>
            <span>{room.occupancy}</span>
          </div>
          <div className="summary-row">
            <span>Check-in</span>
            <span>{formatDateForDisplay(checkIn)}</span>
          </div>
          <div className="summary-row">
            <span>Check-out</span>
            <span>{formatDateForDisplay(checkOut)}</span>
          </div>
          <div className="summary-row">
            <span>Nights</span>
            <span>{nights}</span>
          </div>
          <div className="summary-row">
            <span>Rooms</span>
            <span>{numberOfRooms}</span>
          </div>
          <div className="summary-row">
            <span>Guests</span>
            <span>{guests}</span>
          </div>
          <div className="summary-row">
            <span>Price per room / night</span>
            <span>
              {hotel.currency}
              {room.price.toLocaleString('en-IN')}
            </span>
          </div>

          <div className="summary-total">
            <span>Estimated total</span>
            <span className="summary-total-amount">
              {hotel.currency}
              {total.toLocaleString('en-IN')}
            </span>
          </div>

          {isConfirmed ? (
            <>
              <div className="form-success">
                Booking details ready. Tap below to send this request to our front desk on
                WhatsApp &mdash; we&rsquo;ll confirm availability there.
              </div>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn--forest btn--full"
              >
                Confirm Booking on WhatsApp
              </a>
            </>
          ) : (
            <p className="summary-empty" style={{ marginTop: 18 }}>
              Fill in your details and submit the form to unlock WhatsApp confirmation.
            </p>
          )}
        </>
      )}
    </aside>
  )
}
