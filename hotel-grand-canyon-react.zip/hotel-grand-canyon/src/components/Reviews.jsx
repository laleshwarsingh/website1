import { reviews } from '../data/hotelConfig'

export default function Reviews() {
  return (
    <section className="section" id="reviews">
      <div className="container">
        <div className="section-head">
          <h2>What guests say</h2>
          <p>A few notes from recent stays.</p>
        </div>

        <p className="reviews-note">
          These are sample reviews included as placeholders for this template &mdash; they are not
          verified guest reviews. Replace them with real feedback once the hotel starts collecting
          it.
        </p>

        <div className="reviews-grid">
          {reviews.map((review) => (
            <div className="review-card" key={review.id}>
              <div className="review-card__stars" aria-label={`${review.rating} out of 5 stars`}>
                {'\u2605'.repeat(review.rating)}
                {'\u2606'.repeat(5 - review.rating)}
              </div>
              <p className="review-card__text">{review.text}</p>
              <p className="review-card__name">{review.name}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
