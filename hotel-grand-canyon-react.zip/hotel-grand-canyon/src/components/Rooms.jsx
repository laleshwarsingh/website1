import { hotel, rooms } from '../data/hotelConfig'

export default function Rooms({ onBookRoom }) {
  const handleBook = (roomId) => {
    onBookRoom(roomId)
    const el = document.getElementById('booking')
    if (el) el.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <section className="section section--sand" id="rooms">
      <div className="container">
        <div className="section-head">
          <h2>Rooms &amp; pricing</h2>
          <p>Four straightforward options, priced per night. Pick the one that matches your party size.</p>
        </div>

        <div className="rooms-grid">
          {rooms.map((room) => (
            <div className="room-card" key={room.id}>
              <div className="room-card__image">
                <img src={room.image} alt={`${room.occupancy} room at ${hotel.name}`} />
              </div>
              <div className="room-card__body">
                <div className="room-card__top">
                  <h3 className="room-card__occupancy">{room.occupancy}</h3>
                  <div className="room-card__price">
                    <span className="room-card__price-amount">
                      {hotel.currency}
                      {room.price.toLocaleString('en-IN')}
                    </span>
                    <span className="room-card__price-unit">per night</span>
                  </div>
                </div>
                <p className="room-card__desc">{room.description}</p>
                <button className="btn btn--primary btn--full" onClick={() => handleBook(room.id)}>
                  Book Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
