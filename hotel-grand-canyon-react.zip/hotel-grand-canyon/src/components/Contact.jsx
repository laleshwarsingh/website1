import { hotel } from '../data/hotelConfig'

export default function Contact() {
  return (
    <section className="section" id="contact">
      <div className="container">
        <div className="section-head">
          <h2>Get in touch</h2>
          <p>Call, message on WhatsApp, or email &mdash; whichever is easiest for you.</p>
        </div>

        <div className="contact-grid">
          <div className="contact-card">
            <h4>Call the front desk</h4>
            <p>
              {hotel.phones[0]} &middot; {hotel.phones[1]}
            </p>
            <a href={`tel:${hotel.phones[0]}`} className="btn btn--outline btn--full">
              Call Now
            </a>
          </div>

          <div className="contact-card">
            <h4>Message on WhatsApp</h4>
            <p>Fastest way to check availability or ask a quick question.</p>
            <a
              href={`https://wa.me/${hotel.whatsappNumber}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn--forest btn--full"
            >
              WhatsApp Booking
            </a>
          </div>

          <div className="contact-card">
            <h4>Email us</h4>
            <p>{hotel.email}</p>
            <a href={`mailto:${hotel.email}`} className="btn btn--outline btn--full">
              Send an Email
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
