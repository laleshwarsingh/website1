import { useMemo, useState } from 'react'
import { rooms } from '../data/hotelConfig'
import { todayISO, nightsBetween } from '../utils/dateUtils'
import { buildBookingWhatsAppUrl } from '../utils/whatsapp'
import BookingSummary from './BookingSummary'

const initialFields = {
  fullName: '',
  mobile: '',
  email: '',
  checkIn: '',
  checkOut: '',
  guests: 1,
  numberOfRooms: 1,
  roomId: '',
  specialRequest: '',
}

export default function BookingForm({ selectedRoomId, onSelectRoom }) {
  const [fields, setFields] = useState(initialFields)
  const [errors, setErrors] = useState({})
  const [isConfirmed, setIsConfirmed] = useState(false)
  const [whatsappUrl, setWhatsappUrl] = useState('')

  const roomId = selectedRoomId || fields.roomId
  const room = rooms.find((r) => r.id === roomId) || null
  const nights = nightsBetween(fields.checkIn, fields.checkOut)
  const total = room && nights > 0 ? room.price * nights * Number(fields.numberOfRooms || 1) : 0

  const draft = useMemo(
    () => ({
      room,
      checkIn: fields.checkIn,
      checkOut: fields.checkOut,
      nights: nights > 0 ? nights : 0,
      numberOfRooms: fields.numberOfRooms,
      guests: fields.guests,
      total,
    }),
    [room, fields.checkIn, fields.checkOut, fields.numberOfRooms, fields.guests, nights, total]
  )

  const updateField = (name, value) => {
    setFields((prev) => ({ ...prev, [name]: value }))
    setIsConfirmed(false)
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: undefined }))
  }

  const handleRoomChange = (value) => {
    updateField('roomId', value)
    onSelectRoom(value)
  }

  function validate() {
    const next = {}
    const today = todayISO()

    if (!fields.fullName.trim()) next.fullName = 'Enter your full name.'

    if (!fields.mobile.trim()) {
      next.mobile = 'Enter a mobile number.'
    } else if (!/^[6-9]\d{9}$/.test(fields.mobile.trim())) {
      next.mobile = 'Enter a valid 10-digit Indian mobile number.'
    }

    if (fields.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email.trim())) {
      next.email = 'Enter a valid email address, or leave this blank.'
    }

    if (!fields.checkIn) {
      next.checkIn = 'Select a check-in date.'
    } else if (fields.checkIn < today) {
      next.checkIn = 'Check-in date cannot be in the past.'
    }

    if (!fields.checkOut) {
      next.checkOut = 'Select a check-out date.'
    } else if (fields.checkIn && fields.checkOut <= fields.checkIn) {
      next.checkOut = 'Check-out date must be after check-in date.'
    }

    if (!roomId) next.roomId = 'Select a room type.'

    if (!fields.guests || Number(fields.guests) < 1) next.guests = 'Enter at least 1 guest.'

    if (!fields.numberOfRooms || Number(fields.numberOfRooms) < 1) {
      next.numberOfRooms = 'Enter at least 1 room.'
    }

    setErrors(next)
    return Object.keys(next).length === 0
  }

  function handleSubmit(e) {
    e.preventDefault()
    const isValid = validate()
    if (!isValid || !room) {
      setIsConfirmed(false)
      return
    }

    const booking = {
      fullName: fields.fullName.trim(),
      mobile: fields.mobile.trim(),
      email: fields.email.trim(),
      checkIn: fields.checkIn,
      checkOut: fields.checkOut,
      nights,
      guests: fields.guests,
      numberOfRooms: fields.numberOfRooms,
      occupancy: room.occupancy,
      roomPrice: `\u20b9${room.price.toLocaleString('en-IN')} / night`,
      total: `\u20b9${total.toLocaleString('en-IN')}`,
      specialRequest: fields.specialRequest.trim(),
    }

    setWhatsappUrl(buildBookingWhatsAppUrl(booking))
    setIsConfirmed(true)

    const summaryEl = document.querySelector('.booking-summary')
    if (summaryEl) summaryEl.scrollIntoView({ behavior: 'smooth', block: 'center' })
  }

  return (
    <div className="booking-layout">
      <form className="booking-form" onSubmit={handleSubmit} noValidate>
        <div className="form-row">
          <Field label="Full Name" error={errors.fullName}>
            <input
              type="text"
              value={fields.fullName}
              onChange={(e) => updateField('fullName', e.target.value)}
              placeholder="Your full name"
            />
          </Field>
          <Field label="Mobile Number" error={errors.mobile}>
            <input
              type="tel"
              value={fields.mobile}
              onChange={(e) => updateField('mobile', e.target.value.replace(/\D/g, '').slice(0, 10))}
              placeholder="10-digit mobile number"
            />
          </Field>
        </div>

        <Field label="Email Address (optional)" error={errors.email}>
          <input
            type="email"
            value={fields.email}
            onChange={(e) => updateField('email', e.target.value)}
            placeholder="you@example.com"
          />
        </Field>

        <div className="form-row">
          <Field label="Check-in Date" error={errors.checkIn}>
            <input
              type="date"
              min={todayISO()}
              value={fields.checkIn}
              onChange={(e) => updateField('checkIn', e.target.value)}
            />
          </Field>
          <Field label="Check-out Date" error={errors.checkOut}>
            <input
              type="date"
              min={fields.checkIn || todayISO()}
              value={fields.checkOut}
              onChange={(e) => updateField('checkOut', e.target.value)}
            />
          </Field>
        </div>

        <div className="form-row">
          <Field label="Number of Guests" error={errors.guests}>
            <input
              type="number"
              min="1"
              max="20"
              value={fields.guests}
              onChange={(e) => updateField('guests', e.target.value)}
            />
          </Field>
          <Field label="Number of Rooms" error={errors.numberOfRooms}>
            <input
              type="number"
              min="1"
              max="10"
              value={fields.numberOfRooms}
              onChange={(e) => updateField('numberOfRooms', e.target.value)}
            />
          </Field>
        </div>

        <Field label="Room / Occupancy" error={errors.roomId}>
          <select value={roomId} onChange={(e) => handleRoomChange(e.target.value)}>
            <option value="">Select a room type</option>
            {rooms.map((r) => (
              <option key={r.id} value={r.id}>
                {r.occupancy} &mdash; &#8377;{r.price.toLocaleString('en-IN')} / night
              </option>
            ))}
          </select>
        </Field>

        <Field label="Special Request / Message (optional)">
          <textarea
            value={fields.specialRequest}
            onChange={(e) => updateField('specialRequest', e.target.value)}
            placeholder="Early check-in, extra bed, floor preference, etc."
          />
        </Field>

        <button type="submit" className="btn btn--primary btn--full">
          Review Booking
        </button>
      </form>

      <BookingSummary draft={draft} isConfirmed={isConfirmed} whatsappUrl={whatsappUrl} />
    </div>
  )
}

function Field({ label, error, children }) {
  return (
    <div className={`form-field ${error ? 'form-field--error' : ''}`}>
      <label>{label}</label>
      {children}
      {error && <p className="form-error">{error}</p>}
    </div>
  )
}
