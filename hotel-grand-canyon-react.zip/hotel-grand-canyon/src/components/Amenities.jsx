import { amenities } from '../data/hotelConfig'

export default function Amenities() {
  return (
    <section className="section section--dark" id="amenities">
      <div className="container">
        <div className="section-head">
          <h2>Amenities</h2>
          <p>
            Set as editable placeholders in <code>src/data/hotelConfig.js</code> &mdash; toggle each
            one to match what the property actually offers before launch.
          </p>
        </div>

        <div className="amenities-grid">
          {amenities.map((item) => (
            <div
              className={`amenity-card ${item.available ? '' : 'amenity-card--unavailable'}`}
              key={item.id}
            >
              {item.label}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
