import { hotel } from '../data/hotelConfig'

export default function Location() {
  return (
    <section className="section section--sand" id="location">
      <div className="container">
        <div className="location-layout">
          <div>
            <div className="section-head" style={{ marginBottom: 0 }}>
              <h2>Find us on VIP Road</h2>
            </div>
            <p className="location-address">{hotel.address}</p>
            <a
              href={hotel.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn--primary"
            >
              Get Directions
            </a>
          </div>

          <div className="location-map">
            <iframe
              src={hotel.mapsEmbedUrl}
              title={`Map showing the approximate location of ${hotel.name}`}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
