import { hotel, navLinks } from '../data/hotelConfig'

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer__grid">
          <div>
            <p className="footer__brand">{hotel.name}</p>
            <p className="footer__address">{hotel.address}</p>
            <p style={{ fontSize: '0.92rem' }}>
              {hotel.phones[0]}
              <br />
              {hotel.phones[1]}
            </p>
          </div>

          <div>
            <h5>Quick links</h5>
            <ul>
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a href={link.href}>{link.label}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h5>Book directly</h5>
            <div className="footer__actions">
              <a href="#booking" className="btn btn--primary btn--full">
                Book Now
              </a>
              <a
                href={`https://wa.me/${hotel.whatsappNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn--outline-light btn--full"
              >
                WhatsApp Us
              </a>
            </div>
          </div>
        </div>

        <div className="footer__bottom">
          <span>
            &copy; {year} {hotel.name}. All rights reserved.
          </span>
          <span>Built for direct, commission-free bookings.</span>
        </div>
      </div>
    </footer>
  )
}
