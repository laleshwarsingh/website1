# Hotel Grand Canyon — Website

A React + Vite website for Hotel Grand Canyon (VIP Road, Raipur, Chhattisgarh), with a working
booking form that calculates the total and hands the request off to WhatsApp.

## Run it locally

```bash
npm install
npm run dev
```

Opens at `http://localhost:5173`.

## Build for deployment

```bash
npm run build
```

This produces a static `dist/` folder. Deploy it to any static host:

- **Netlify / Vercel**: connect the repo, build command `npm run build`, output directory `dist`
- **GitHub Pages / any static host**: upload the contents of `dist/` directly

No backend or server is required — everything runs in the browser.

## What to edit before launching

Everything hotel-specific lives in **one file**: `src/data/hotelConfig.js`.

- `hotel.phones`, `hotel.whatsappNumber`, `hotel.email` — contact details
- `hotel.mapsUrl` / `hotel.mapsEmbedUrl` — replace with the hotel's real Google Maps share link
  and embed link once you have them
- `rooms` — occupancy, pricing, description and image per room type
- `amenities` — set `available: true/false` per item to match what the property actually offers
- `reviews` — sample/placeholder reviews; replace with real guest feedback once you have it
- Room and hero images currently use placeholder photos from `picsum.photos`. Swap the `image`
  URLs in `hotelConfig.js` (and the two `<img>` sources in `Hero.jsx` / `About.jsx`) for real
  photos of the property.

## How the booking flow works

1. A guest picks a room (from the Rooms section or the booking form) and dates.
2. `src/utils/dateUtils.js` validates that check-in isn't in the past and check-out is after
   check-in, and calculates the number of nights.
3. `BookingForm.jsx` calculates **nights × room price × number of rooms** live and passes it to
   `BookingSummary.jsx`.
4. On submit, all fields are validated. If valid, `src/utils/whatsapp.js` builds a
   `https://wa.me/<number>?text=...` link with the complete booking request, and a
   "Confirm Booking on WhatsApp" button appears.
5. Clicking that button opens WhatsApp (app or web) with the message pre-filled. The guest still
   presses Send — this is the standard WhatsApp click-to-chat mechanism, not an automatic backend
   send.

### Upgrading to automatic sending (WhatsApp Business Cloud API)

The click-to-chat link is a deliberate frontend-only choice — sending a WhatsApp message
automatically, without the guest pressing Send, requires a backend calling Meta's WhatsApp
Business Cloud API with an access token, which can't run safely in browser code. To upgrade later:

1. Set up a WhatsApp Business Cloud API account and phone number ID with Meta.
2. Add a small backend endpoint (e.g. a serverless function) that accepts the booking object and
   calls `https://graph.facebook.com/v20.0/<phone-number-id>/messages` with your access token.
3. In `src/utils/whatsapp.js`, replace the body of `buildBookingWhatsAppUrl` with a `fetch()` call
   to your new endpoint instead of returning a `wa.me` URL. Every booking field is already passed
   in as one flat object, so the rest of the form code doesn't need to change.

## Project structure

```
src/
  data/hotelConfig.js     # all editable hotel content
  utils/dateUtils.js      # date validation + night calculation
  utils/whatsapp.js       # WhatsApp message builder
  components/
    Navbar.jsx
    Hero.jsx
    About.jsx
    Rooms.jsx
    BookingForm.jsx
    BookingSummary.jsx
    Reviews.jsx
    Amenities.jsx
    Location.jsx
    Contact.jsx
    Footer.jsx
  App.jsx
  main.jsx
  index.css               # design tokens + all styling
```
